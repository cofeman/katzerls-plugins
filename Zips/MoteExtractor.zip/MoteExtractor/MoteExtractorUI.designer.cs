﻿namespace katzerle
{
    partial class MoteExtractorUI
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.CBArcaneVortex = new System.Windows.Forms.CheckBox();
            this.CBWindyCloud = new System.Windows.Forms.CheckBox();
            this.CBFelmist = new System.Windows.Forms.CheckBox();
            this.CBSwampGas = new System.Windows.Forms.CheckBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.CBArticCloud = new System.Windows.Forms.CheckBox();
            this.CBCinderCloud = new System.Windows.Forms.CheckBox();
            this.CBSteamCloud = new System.Windows.Forms.CheckBox();
            this.BSave = new System.Windows.Forms.Button();
            this.BReport = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.TBBlacklistTimer = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.CBFelmist);
            this.groupBox1.Controls.Add(this.CBArcaneVortex);
            this.groupBox1.Controls.Add(this.CBWindyCloud);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(13, 13);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(279, 122);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Outland Clouds";
            // 
            // CBArcaneVortex
            // 
            this.CBArcaneVortex.AutoSize = true;
            this.CBArcaneVortex.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CBArcaneVortex.Location = new System.Drawing.Point(7, 44);
            this.CBArcaneVortex.Name = "CBArcaneVortex";
            this.CBArcaneVortex.Size = new System.Drawing.Size(239, 17);
            this.CBArcaneVortex.TabIndex = 1;
            this.CBArcaneVortex.Text = "Arcane Vortex (Motes of Mana) - Netherstorm";
            this.CBArcaneVortex.UseVisualStyleBackColor = true;
            // 
            // CBWindyCloud
            // 
            this.CBWindyCloud.AutoSize = true;
            this.CBWindyCloud.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CBWindyCloud.Location = new System.Drawing.Point(7, 20);
            this.CBWindyCloud.Name = "CBWindyCloud";
            this.CBWindyCloud.Size = new System.Drawing.Size(201, 17);
            this.CBWindyCloud.TabIndex = 0;
            this.CBWindyCloud.Text = "Windy Cloud (Motes of Air) - Nagrand";
            this.CBWindyCloud.UseVisualStyleBackColor = true;
            // 
            // CBFelmist
            // 
            this.CBFelmist.AutoSize = true;
            this.CBFelmist.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CBFelmist.Location = new System.Drawing.Point(7, 68);
            this.CBFelmist.Name = "CBFelmist";
            this.CBFelmist.Size = new System.Drawing.Size(255, 17);
            this.CBFelmist.TabIndex = 2;
            this.CBFelmist.Text = "Felmist (Motes of Shadow) - Shadowmoon Valley";
            this.CBFelmist.UseVisualStyleBackColor = true;
            // 
            // CBSwampGas
            // 
            this.CBSwampGas.AutoSize = true;
            this.CBSwampGas.Location = new System.Drawing.Point(20, 105);
            this.CBSwampGas.Name = "CBSwampGas";
            this.CBSwampGas.Size = new System.Drawing.Size(233, 17);
            this.CBSwampGas.TabIndex = 1;
            this.CBSwampGas.Text = "Swamp Gas Motes of Water) - Zangarmarsh";
            this.CBSwampGas.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.CBSteamCloud);
            this.groupBox2.Controls.Add(this.CBCinderCloud);
            this.groupBox2.Controls.Add(this.CBArticCloud);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(13, 142);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(279, 95);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Northend Clouds";
            // 
            // CBArticCloud
            // 
            this.CBArticCloud.AutoSize = true;
            this.CBArticCloud.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CBArticCloud.Location = new System.Drawing.Point(7, 20);
            this.CBArticCloud.Name = "CBArticCloud";
            this.CBArticCloud.Size = new System.Drawing.Size(248, 17);
            this.CBArticCloud.TabIndex = 0;
            this.CBArticCloud.Text = "Arctic Cloud (Crystallized Air/Water) - Icy areas ";
            this.CBArticCloud.UseVisualStyleBackColor = true;
            // 
            // CBCinderCloud
            // 
            this.CBCinderCloud.AutoSize = true;
            this.CBCinderCloud.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CBCinderCloud.Location = new System.Drawing.Point(7, 43);
            this.CBCinderCloud.Name = "CBCinderCloud";
            this.CBCinderCloud.Size = new System.Drawing.Size(222, 17);
            this.CBCinderCloud.TabIndex = 0;
            this.CBCinderCloud.Text = "Cinder Cloud (Crystallized Fire) - Fire areas";
            this.CBCinderCloud.UseVisualStyleBackColor = true;
            // 
            // CBSteamCloud
            // 
            this.CBSteamCloud.AutoSize = true;
            this.CBSteamCloud.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CBSteamCloud.Location = new System.Drawing.Point(7, 66);
            this.CBSteamCloud.Name = "CBSteamCloud";
            this.CBSteamCloud.Size = new System.Drawing.Size(269, 17);
            this.CBSteamCloud.TabIndex = 0;
            this.CBSteamCloud.Text = "Steam Cloud (Crystallized Water/Fire) - Humid areas";
            this.CBSteamCloud.UseVisualStyleBackColor = true;
            // 
            // BSave
            // 
            this.BSave.Location = new System.Drawing.Point(11, 272);
            this.BSave.Name = "BSave";
            this.BSave.Size = new System.Drawing.Size(133, 23);
            this.BSave.TabIndex = 3;
            this.BSave.Text = "Save Settings";
            this.BSave.UseVisualStyleBackColor = true;
            this.BSave.Click += new System.EventHandler(this.BSave_Click);
            // 
            // BReport
            // 
            this.BReport.Location = new System.Drawing.Point(159, 272);
            this.BReport.Name = "BReport";
            this.BReport.Size = new System.Drawing.Size(133, 23);
            this.BReport.TabIndex = 3;
            this.BReport.Text = "Generate Report";
            this.BReport.UseVisualStyleBackColor = true;
            this.BReport.Click += new System.EventHandler(this.BReport_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(13, 244);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(131, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Blacklist Clouds after ";
            // 
            // TBBlacklistTimer
            // 
            this.TBBlacklistTimer.Location = new System.Drawing.Point(150, 241);
            this.TBBlacklistTimer.Name = "TBBlacklistTimer";
            this.TBBlacklistTimer.Size = new System.Drawing.Size(51, 20);
            this.TBBlacklistTimer.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(207, 244);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Seconds";
            // 
            // MoteExtractorUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(304, 308);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.TBBlacklistTimer);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.BReport);
            this.Controls.Add(this.BSave);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.CBSwampGas);
            this.Controls.Add(this.groupBox1);
            this.Name = "MoteExtractorUI";
            this.Text = "Mote Extractor";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox CBArcaneVortex;
        private System.Windows.Forms.CheckBox CBWindyCloud;
        private System.Windows.Forms.CheckBox CBFelmist;
        private System.Windows.Forms.CheckBox CBSwampGas;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.CheckBox CBSteamCloud;
        private System.Windows.Forms.CheckBox CBCinderCloud;
        private System.Windows.Forms.CheckBox CBArticCloud;
        private System.Windows.Forms.Button BSave;
        private System.Windows.Forms.Button BReport;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TBBlacklistTimer;
        private System.Windows.Forms.Label label2;
    }
}

