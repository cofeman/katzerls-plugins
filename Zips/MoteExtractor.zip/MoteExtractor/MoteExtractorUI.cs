﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Xml.Linq;
using System.Diagnostics;
using System.IO;
using System.Xml;
using System.Windows.Forms;
using System.Net;
using System.Globalization;
using System.Windows.Media;
using System.Media;
using System.Linq;

using Styx;
using Styx.Common;
using Styx.CommonBot;
using Styx.Helpers;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using Styx.Plugins;
using Styx.Pathing;
using Styx.WoWInternals.World;

namespace katzerle
{
    public partial class MoteExtractorUI : Form
    {
        public MoteExtractorUI()
        {
            InitializeComponent();
            CBArcaneVortex.Checked = MotesExtractor.Settings.ArcaneVortex;
            CBArticCloud.Checked = MotesExtractor.Settings.ArcticCloud;
            CBCinderCloud.Checked = MotesExtractor.Settings.CinderCloud;
            CBFelmist.Checked = MotesExtractor.Settings.Felmist;
            CBSteamCloud.Checked = MotesExtractor.Settings.SteamCloud;
            CBSwampGas.Checked = MotesExtractor.Settings.SwampGas;
            CBWindyCloud.Checked = MotesExtractor.Settings.WindyCloud;
            TBBlacklistTimer.Text = MotesExtractor.Settings.BlacklistTimer;
        }

        private void BReport_Click(object sender, EventArgs e)
        {
            MotesExtractor.GenerateReport();
        }

        private void BSave_Click(object sender, EventArgs e)
        {
            //----------------- Save Configfile and set Settings ---------------- 
            XmlDocument xml;
            XmlElement root;
            XmlElement element;
            XmlText text;
            XmlComment xmlComment;

            MotesExtractor.Settings.ArcaneVortex = CBArcaneVortex.Checked;
            MotesExtractor.Settings.ArcticCloud = CBArticCloud.Checked;
            MotesExtractor.Settings.CinderCloud = CBCinderCloud.Checked;
            MotesExtractor.Settings.Felmist = CBFelmist.Checked;
            MotesExtractor.Settings.SteamCloud = CBSteamCloud.Checked;
            MotesExtractor.Settings.SwampGas = CBSwampGas.Checked;
            MotesExtractor.Settings.WindyCloud = CBWindyCloud.Checked;
            MotesExtractor.Settings.BlacklistTimer = TBBlacklistTimer.Text;

            Logging.WriteDiagnostic("Mote Extractor Save: ArcaneVortex = {0}", CBArcaneVortex.Checked.ToString());
            Logging.WriteDiagnostic("Mote Extractor Save: ArcticCloud = {0}", CBArticCloud.Checked.ToString());
            Logging.WriteDiagnostic("Mote Extractor Save: CinderCloud = {0}", CBCinderCloud.Checked.ToString());
            Logging.WriteDiagnostic("Mote Extractor Save: Felmist = {0}", CBFelmist.Checked.ToString());
            Logging.WriteDiagnostic("Mote Extractor Save: SteamCloud = {0}", CBSteamCloud.Checked.ToString());
            Logging.WriteDiagnostic("Mote Extractor Save: SwampGas = {0}", CBSwampGas.Checked.ToString());
            Logging.WriteDiagnostic("Mote Extractor Save: WindyCloud = {0}", CBWindyCloud.Checked.ToString());
            Logging.WriteDiagnostic("Mote Extractor Save: BlacklistTimer = {0}", TBBlacklistTimer.Text.ToString());

            // ---------- Save ----------------------------			
            string sPath = Path.Combine(MotesExtractor.FolderPath, "config\\MoteExtractor.config");

            Logging.WriteDiagnostic("Mote Extractor: Saving config file: {0}", sPath);
            Logging.Write("Mote Extractor: Settings Saved");
            xml = new XmlDocument();
            XmlDeclaration dc = xml.CreateXmlDeclaration("1.0", "utf-8", null);
            xml.AppendChild(dc);

            xmlComment = xml.CreateComment(
                "=======================================================================\n" +
                ".CONFIG  -  This is the Config File For Mote Extractor\n\n" +
                "XML file containing settings to customize in the Mote Extractor Plugin\n" +
                "It is STRONGLY recommended you use the Configuration UI to change this\n" +
                "file instead of direct changein it here.\n" +
                "========================================================================");

            //let's add the root element
            root = xml.CreateElement("MoteExtractor");
            root.AppendChild(xmlComment);

            //Rarekiller
            //let's add another element (child of the root)
            element = xml.CreateElement("ArcaneVortex");
            text = xml.CreateTextNode(CBArcaneVortex.Checked.ToString());
            element.AppendChild(text);
            root.AppendChild(element);

            //let's add another element (child of the root)
            element = xml.CreateElement("WindyCloud");
            text = xml.CreateTextNode(CBWindyCloud.Checked.ToString());
            element.AppendChild(text);
            root.AppendChild(element);

            //let's add another element (child of the root)
            element = xml.CreateElement("Felmist");
            text = xml.CreateTextNode(CBFelmist.Checked.ToString());
            element.AppendChild(text);
            root.AppendChild(element);

            //let's add another element (child of the root)
            element = xml.CreateElement("SwampGas");
            text = xml.CreateTextNode(CBSwampGas.Checked.ToString());
            element.AppendChild(text);
            root.AppendChild(element);

            //let's add another element (child of the root)
            element = xml.CreateElement("ArcticCloud");
            text = xml.CreateTextNode(CBArticCloud.Checked.ToString());
            element.AppendChild(text);
            root.AppendChild(element);

            //let's add another element (child of the root)
            element = xml.CreateElement("CinderCloud");
            text = xml.CreateTextNode(CBCinderCloud.Checked.ToString());
            element.AppendChild(text);
            root.AppendChild(element);

            //let's add another element (child of the root)
            element = xml.CreateElement("SteamCloud");
            text = xml.CreateTextNode(CBSteamCloud.Checked.ToString());
            element.AppendChild(text);
            root.AppendChild(element);

            //let's add another element (child of the root)
            element = xml.CreateElement("BlacklistTimer");
            text = xml.CreateTextNode(TBBlacklistTimer.Text.ToString());
            element.AppendChild(text);
            root.AppendChild(element);

            xml.AppendChild(root);

            System.IO.FileStream fs = new System.IO.FileStream(@sPath, System.IO.FileMode.Create,
                                                               System.IO.FileAccess.Write);
            try
            {
                xml.Save(fs);
                fs.Close();
            }
            catch (Exception np)
            {
                Logging.Write(Colors.Red, np.Message);
            }
        }


    }
}
