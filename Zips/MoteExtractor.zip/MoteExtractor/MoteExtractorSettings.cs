﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Xml.Linq;
using System.Diagnostics;
using System.IO;
using System.Xml;
using System.Windows.Forms;
using System.Net;
using System.Globalization;
using System.Windows.Media;
using System.Media;
using System.Linq;

using Styx;
using Styx.Common;
using Styx.CommonBot;
using Styx.Helpers;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using Styx.Plugins;
using Styx.Pathing;
using Styx.WoWInternals.World;

namespace katzerle
{
    class MoteExtractorSettings
    {
        public MoteExtractorSettings()
        {
            if (StyxWoW.Me != null)
                try
                {
                    Load();
                }
                catch (Exception e)
                {
                    Logging.Write(Colors.Red, e.Message);
                }
        }

        public bool ArcaneVortex = true;
        public bool WindyCloud = true;
        public bool Felmist = true;
        public bool SwampGas = true;
        public bool SteamCloud = true;
        public bool CinderCloud = true;
        public bool ArcticCloud = true;
        public string BlacklistTimer = "30";
		
		// -------------- Load ConfigFile ---------------
        public void Load()
        {
            //    XmlTextReader reader;
            XmlDocument xml = new XmlDocument();
            XmlNode xvar;

            string sPath = Path.Combine(MotesExtractor.FolderPath, "config\\MoteExtractor.config");

            Logging.WriteDiagnostic("Mote Extractor: Loading config file: {0}", sPath);
            System.IO.FileStream fs = new System.IO.FileStream(@sPath, System.IO.FileMode.OpenOrCreate, System.IO.FileAccess.ReadWrite);
            try
            {
                xml.Load(fs);
                fs.Close();
            }
            catch (Exception e)
            {
                Logging.WriteDiagnostic(e.Message);
                Logging.Write("Mote Extractor: Continuing with Default Config Values");
                fs.Close();
                return;
            }

            //            xml = new XmlDocument();

            try
            {
                //                xml.Load(reader);
                if (xml == null)
                    return;
                // Load Variables
                xvar = xml.SelectSingleNode("//MoteExtractor/ArcaneVortex");
                if (xvar != null)
                {
                    ArcaneVortex = Convert.ToBoolean(xvar.InnerText);
                    Logging.WriteDiagnostic("Mote Extractor Load: " + xvar.Name + "=" + ArcaneVortex.ToString());
                }
                xvar = xml.SelectSingleNode("//MoteExtractor/WindyCloud");
                if (xvar != null)
                {
                    WindyCloud = Convert.ToBoolean(xvar.InnerText);
                    Logging.WriteDiagnostic("Mote Extractor Load: " + xvar.Name + "=" + WindyCloud.ToString());
                }
                xvar = xml.SelectSingleNode("//MoteExtractor/Felmist");
                if (xvar != null)
                {
                    Felmist = Convert.ToBoolean(xvar.InnerText);
                    Logging.WriteDiagnostic("Mote Extractor Load: " + xvar.Name + "=" + Felmist.ToString());
                }
                xvar = xml.SelectSingleNode("//MoteExtractor/SwampGas");
                if (xvar != null)
                {
                    SwampGas = Convert.ToBoolean(xvar.InnerText);
                    Logging.WriteDiagnostic("Mote Extractor Load: " + xvar.Name + "=" + SwampGas.ToString());
                }

                xvar = xml.SelectSingleNode("//MoteExtractor/ArcticCloud");
                if (xvar != null)
                {
                    ArcticCloud = Convert.ToBoolean(xvar.InnerText);
                    Logging.WriteDiagnostic("Mote Extractor Load: " + xvar.Name + "=" + ArcticCloud.ToString());
                }
                xvar = xml.SelectSingleNode("//MoteExtractor/CinderCloud");
                if (xvar != null)
                {
                    CinderCloud = Convert.ToBoolean(xvar.InnerText);
                    Logging.WriteDiagnostic("Mote Extractor Load: " + xvar.Name + "=" + CinderCloud.ToString());
                }
                xvar = xml.SelectSingleNode("//MoteExtractor/SteamCloud");
                if (xvar != null)
                {
                    SteamCloud = Convert.ToBoolean(xvar.InnerText);
                    Logging.WriteDiagnostic("Mote Extractor Load: " + xvar.Name + "=" + SteamCloud.ToString());
                }


                xvar = xml.SelectSingleNode("//MoteExtractor/BlacklistTimer");
                if (xvar != null)
                {
                    BlacklistTimer = Convert.ToString(xvar.InnerText);
                    Logging.WriteDiagnostic("Mote Extractor Load: " + xvar.Name + "=" + BlacklistTimer.ToString());
                }
			}
            catch (Exception e)
            {
                Logging.WriteDiagnostic("Mote Extractor: PROJECTE EXCEPTION, STACK=" + e.StackTrace);
                Logging.WriteDiagnostic("Mote Extractor: PROJECTE EXCEPTION, SRC=" + e.Source);
                Logging.WriteDiagnostic("Mote Extractor: PROJECTE : " + e.Message);
            }
		}
    }
}
