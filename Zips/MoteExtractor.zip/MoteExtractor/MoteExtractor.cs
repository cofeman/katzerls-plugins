﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Xml.Linq;
using System.Diagnostics;
using System.IO;
using System.Xml;
using System.Windows.Forms;
using System.Net;
using System.Globalization;
using System.Windows.Media;
using System.Media;
using System.Linq;

using Styx;
using Styx.Common;
using Styx.CommonBot;
using Styx.Helpers;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using Styx.Plugins;
using Styx.Pathing;
using Styx.WoWInternals.World;


namespace katzerle
{
    class MotesExtractor : HBPlugin
    {
        public override string Name { get { return "MotesExtractor"; } }
        public override string Author { get { return "katzerle"; } }
        private readonly Version _version = new Version(1, 0);
        public override Version Version { get { return _version; } }
        public override string ButtonText { get { return "Settings"; } }
        public override bool WantButton { get { return true; } }

        public static MoteExtractorSettings Settings = new MoteExtractorSettings();
        public static LocalPlayer Me = StyxWoW.Me;
        public static bool hasItBeenInitialized = false;
        public static List<WoWPoint> BlacklistedSpots = new List<WoWPoint>();
        public static List<WoWItem> ExtractorList;
        public static Stopwatch BlacklistTimer = new Stopwatch();
        public static Stopwatch Runtime = new Stopwatch();

        public static float MoteAirStart = 0;
        public static float MoteManaStart = 0;
        public static float MoteShadowStart = 0;
        public static float MoteWaterStart = 0;
        public static float crystAirStart = 0;
        public static float crystWaterStart = 0;
        public static float crystFireStart = 0;

        public static Int32 Clouds = 0;

        public MotesExtractor()
        {
            Settings.Load();
            Logging.Write(Colors.Aquamarine, "Mote Extractor - Version 1.0 Loaded.");
        }

        static private void BotStopped(EventArgs args)
        {
            BotEvents.OnBotStopped -= BotStopped;
            ExtractorList.Clear();
            BlacklistedSpots.Clear();
            GenerateReport();
            hasItBeenInitialized = false;
            Runtime.Stop();
            Runtime.Reset();
            Clouds = 0;
        }

        public override void OnButtonPress()
        {
            Settings.Load();
            ConfigForm.ShowDialog();
        }

        private Form MyForm;
        public Form ConfigForm
        {
            get
            {
                if (MyForm == null)
                    MyForm = new MoteExtractorUI();
                return MyForm;
            }
        }

        static public void Initialize()
        {
            //Init Done
            hasItBeenInitialized = true;
			
			//Searching for Mote Extractor
            ObjectManager.Update();
            ExtractorList = ObjectManager.GetObjectsOfType<WoWItem>()
                .Where(Extractor => (Extractor.Entry == 23821))
                .OrderBy(Extractor => Extractor.Distance).ToList();
            if (ExtractorList == null)
                Logging.Write(Colors.Red, "No Extractor Found, Plugin deactivated");

            //Searching for Motes etc in Inventary
            MoteAirStart = GetMotesInventary("MoteAir");
            MoteManaStart = GetMotesInventary("MoteMana");
            MoteShadowStart = GetMotesInventary("MoteShadow");
            MoteWaterStart = GetMotesInventary("MoteWater");
            crystAirStart = GetMotesInventary("crystAir");
            crystWaterStart = GetMotesInventary("crystWater");
            crystFireStart = GetMotesInventary("crystFire");

            // Register the events of the Start/Stop Button in HB
            BotEvents.OnBotStopped += BotStopped;

            // Blackspots Profile --> Moteslist --> ToDo
            // BlacklistedSpots = ProfileManager.CurrentProfile.Blackspots.ConvertAll<WoWPoint>(hs => hs.ToWoWPoint());

            //Motes from XML to List
            XmlDocument MotesXML = new XmlDocument();
            string sPath = Path.Combine(FolderPath, "config\\MotesBlacklist.xml");
            System.IO.FileStream fs = new System.IO.FileStream(@sPath, System.IO.FileMode.OpenOrCreate, System.IO.FileAccess.ReadWrite);
            try
            {
                MotesXML.Load(fs);
                fs.Close();
            }
            catch (Exception e)
            {
                Logging.Write(Colors.Red, e.Message);
                fs.Close();
                return;
            }
            XmlElement root = MotesXML.DocumentElement;
            foreach (XmlNode Node in root.ChildNodes)
            {
				//ToDo
				//WoWPoint BlackPoint = new WoWPoint(0, 0, 0);
                WoWPoint BlackPoint = new WoWPoint(Convert.ToDouble(Node.Attributes["X"].InnerText), Convert.ToDouble(Node.Attributes["Y"].InnerText), Convert.ToDouble(Node.Attributes["Z"].InnerText));
                BlacklistedSpots.Add(BlackPoint);
            }
            // Debug
            foreach (WoWPoint BlackPoint in BlacklistedSpots)
                Logging.Write(Colors.Green, "Mote Extractor: Blacklisted Spot: {0}", BlackPoint.ToString());

        }

        static public bool InPetCombat()
        {
            List<string> cnt = Lua.GetReturnValues("dummy,reason=C_PetBattles.IsTrapAvailable() return dummy,reason");
            if (cnt != null) { if (cnt[1] != "0") return true; }
            return false;
        }


        public override void Pulse()
        {

            try
            {
                if (!hasItBeenInitialized)
                    Initialize();

                if (!Runtime.IsRunning)
                {
                    Runtime.Reset();
                    Runtime.Start();
                }

                // ------------ Deactivate if not in Game etc
                if (Me == null || !StyxWoW.IsInGame || Me.IsDead || Me.IsGhost || InPetCombat())
                    return;

                // ------------ Deactivate Plugin in BGs, Inis and on Transport
                if (Battlegrounds.IsInsideBattleground || Me.IsInInstance || Me.IsOnTransport)
                    return;
                // ------------ Deactivate if no Extractor in Inventory
                if (ExtractorList == null)
                    return;

                // ------------ Find and Pickup Clouds
                if (!inCombat)
                    FindAndPickupClouds();
            }
            catch (ThreadAbortException) { }
            catch (Exception e)
            {
                Logging.Write(Colors.Red, "Exception in Pulse:{0}", e);
            }
        }

        static public void FindAndPickupClouds()
        {
            BlacklistFlags Flags = BlacklistFlags.All;
            //Logging.Write(Colors.Green, "Search");
			ObjectManager.Update();
            List<WoWUnit> objList = ObjectManager.GetObjectsOfType<WoWUnit>()
                .Where(o => (((o.Entry == 17408) && Settings.ArcaneVortex)
                || ((o.Entry == 24222) && Settings.WindyCloud)
                || ((o.Entry == 24879) && Settings.ArcticCloud)
                || ((o.Entry == 32522) && Settings.CinderCloud)
                || ((o.Entry == 17407) && Settings.Felmist)
                || ((o.Entry == 32544) && Settings.SteamCloud)
                || ((o.Entry == 17378) && Settings.SwampGas)
                ))
                .OrderByDescending(o => o.Entry).ToList();
            foreach (WoWUnit o in objList)
            {
                if (Blacklist.Contains(o.Guid, Flags))
                    return;

                foreach (WoWPoint BlackPoint in BlacklistedSpots)
                {
					//Logging.Write(Colors.Green, "Unit-Blackspot Distance: {0}", o.Location.Distance(BlackPoint));
                    if (o.Location.Distance(BlackPoint) < 40)
                        return;
                }

                Logging.Write(Colors.Green, "Mote Extractor: Found a Cloud {0} Guid {1}, Location {2}", o.Name, o.Guid, o.Location.ToString());
                while (Me.IsCasting)
                {
                    Thread.Sleep(100);
                }

                BlacklistTimer.Reset();
                BlacklistTimer.Start();
                while (o.Location.Distance(Me.Location) > 3)
                {
                    Flightor.MoveTo(o.Location);
					
                    if (inCombat) return;

                    if (BlacklistTimer.Elapsed.TotalSeconds > Convert.ToInt32(Settings.BlacklistTimer))
                    {
                        Logging.Write(Colors.Red, "Mote Extractor: Can't reach {0} Guid {1}, Location {2}, Blacklist and Move on", o.Name, o.Guid, o.Location.ToString());
                        Blacklist.Add(o.Guid, Flags, TimeSpan.FromSeconds(3600));
                        BlacklistTimer.Reset();
                        WoWMovement.MoveStop();
                        return;
                    }
                }

                WoWMovement.Move(WoWMovement.MovementDirection.Descend);
                Thread.Sleep(1000);
                if (Me.IsFlying && !inCombat)
                    Thread.Sleep(1000);
                if (Me.IsFlying && !inCombat)
                    Thread.Sleep(1000);
                WoWMovement.MoveStop();
                //Dismount
                if (Me.Mounted)
                    Lua.DoString("Dismount()");
                Thread.Sleep(300);

				if(o.Location.Distance(Me.Location) > 10)
				{
					BlacklistTimer.Reset();
					BlacklistTimer.Start();
					while (o.Location.Distance(Me.Location) > 3)
					{
						Navigator.MoveTo(o.Location);
						if (inCombat) return;

						if (BlacklistTimer.Elapsed.TotalSeconds > 10)
						{
							Logging.Write(Colors.Red, "Mote Extractor: Can't reach {0} Guid {1}, Location {2}, Blacklist and Move on", o.Name, o.Guid, o.Location.ToString());
							Blacklist.Add(o.Guid, Flags, TimeSpan.FromSeconds(3600));
							BlacklistTimer.Reset();
							WoWMovement.MoveStop();
							return;
						}
					}
				}

                o.Target();
                o.Face();
                Thread.Sleep(1000);

                foreach (WoWItem Extractor in ExtractorList)
                {
                    WoWMovement.MoveStop();
                    Extractor.Use();
                    Thread.Sleep(3500);
                }
                Clouds++;
                return;

            }
        }


        static public void GenerateReport()
        {
            float MoteAirStop = 0;
            float MoteManaStop = 0;
            float MoteShadowStop = 0;
            float MoteWaterStop = 0;
            float crystAirStop = 0;
            float crystWaterStop = 0;
            float crystFireStop = 0;
            float CloudsHour = 0;

            MoteAirStop = GetMotesInventary("MoteAir") - MoteAirStart;
            MoteManaStop = GetMotesInventary("MoteMana") - MoteManaStart;
            MoteShadowStop = GetMotesInventary("MoteShadow") - MoteShadowStart;
            MoteWaterStop = GetMotesInventary("MoteWater") - MoteWaterStart;
            crystAirStop = GetMotesInventary("crystAir") - crystAirStart;
            crystWaterStop = GetMotesInventary("crystWater") - crystWaterStart;
            crystFireStop = GetMotesInventary("crystFire") - crystFireStart;
			if (Runtime.Elapsed.Hours!=0)
				CloudsHour = Clouds/Runtime.Elapsed.Hours;
			else
				CloudsHour = 0;

            Logging.Write(Colors.Green, "-- Mote Extractor plugin report:");

            Logging.Write(Colors.Green, "-- Total run time: {0}h{1}min", Runtime.Elapsed.Hours, Runtime.Elapsed.Minutes);
            Logging.Write(Colors.Green, "-- Total Clouds extracted {0} ({1} clouds/hour):", Clouds, CloudsHour);

            Logging.Write(Colors.Green, "-- Mote of Water: {0}", MoteWaterStop);
            Logging.Write(Colors.Green, "-- Mote of Air: {0}", MoteAirStop);
            Logging.Write(Colors.Green, "-- Mote of Mana: {0}", MoteManaStop);
            Logging.Write(Colors.Green, "-- Mote of Shadow: {0}", MoteShadowStop);

            Logging.Write(Colors.Green, "-- crystallized Air: {0}", crystAirStop);
            Logging.Write(Colors.Green, "-- crystallized Fire: {0}", crystFireStop);
            Logging.Write(Colors.Green, "-- crystallized Water: {0}", crystWaterStop);

            Logging.Write(Colors.Green, "-- End of Report");
        }

        static public float GetMotesInventary(string Mote)
        {
            float MotesInventary = 0;
			Int32 MoteID = 0;
			Int32 PrimalID = 0;
			
			if (Mote == "MoteAir")
			{
				MoteID = 22572;
				PrimalID = 22451;
			}
			
			else if (Mote == "MoteWater")
			{
				MoteID = 22578;
				PrimalID = 21885;
			}
			
			else if (Mote == "MoteShadow")
			{
				MoteID = 22577;
				PrimalID = 22456;
			}
			
			else if (Mote == "MoteMana")
			{
				MoteID = 22576;
				PrimalID = 22457;
			}
			
			else if (Mote == "crystAir")
			{
				MoteID = 37700;
				PrimalID = 35623;
			}
			
			else if (Mote == "crystWater")
			{
				MoteID = 37705;
				PrimalID = 35622;
			}
			
			else if (Mote == "crystFire")
			{
				MoteID = 37702;
				PrimalID = 36860;
			}

			List<WoWItem> objList = ObjectManager.GetObjectsOfType<WoWItem>()
					.Where(o => (o.Entry == MoteID))
					.OrderBy(o => o.Distance).ToList();
			foreach (WoWItem o in objList)
			{
				MotesInventary = MotesInventary + o.StackCount;
			}
			objList.Clear();
			objList = ObjectManager.GetObjectsOfType<WoWItem>()
					.Where(o => (o.Entry == PrimalID))
					.OrderBy(o => o.Distance).ToList();
			foreach (WoWItem o in objList)
			{
				MotesInventary = MotesInventary + (o.StackCount * 10);
			}
			//Logging.Write(Colors.Green, "Mote Extractor: {0} in Inventary: {1}", Mote, MotesInventary);
            return MotesInventary;
        }


        static public string FolderPath
        {
            get
            {
                string sPath = Process.GetCurrentProcess().MainModule.FileName;
                sPath = Path.GetDirectoryName(sPath);
                sPath = Path.Combine(sPath, "Plugins\\MoteExtractor\\");
                return sPath;
            }
        }


        static public bool inCombat
        {
            get
            {
                if (Me.Combat || Me.IsDead || Me.IsGhost) return true;
                return false;
            }
        }
    }
}
