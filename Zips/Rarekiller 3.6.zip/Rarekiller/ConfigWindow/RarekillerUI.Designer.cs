﻿//=================================================================
//
//				      Rarekiller - Plugin
//						Autor: katzerle
//			Honorbuddy Plugin - www.thebuddyforum.com
//    Credits to highvoltz, bloodlove, SMcCloud, Lofi, ZapMan 
//                and all the brave Testers
//
//==================================================================
namespace katzerle
{
    partial class RarekillerUI
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.GBAddon = new System.Windows.Forms.GroupBox();
            this.CBKillList = new System.Windows.Forms.CheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.CBLowRAR = new System.Windows.Forms.CheckBox();
            this.TBHuntByID = new System.Windows.Forms.TextBox();
            this.CBBC = new System.Windows.Forms.CheckBox();
            this.CBHuntByID = new System.Windows.Forms.CheckBox();
            this.CBWotlk = new System.Windows.Forms.CheckBox();
            this.CBCata = new System.Windows.Forms.CheckBox();
            this.CBPoseidus = new System.Windows.Forms.CheckBox();
            this.CBTLPD = new System.Windows.Forms.CheckBox();
            this.CBMOP = new System.Windows.Forms.CheckBox();
            this.CBRaptorNest = new System.Windows.Forms.CheckBox();
            this.GBSlowfall = new System.Windows.Forms.GroupBox();
            this.TBFalltimer = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.CBSpell = new System.Windows.Forms.CheckBox();
            this.CBItem = new System.Windows.Forms.CheckBox();
            this.CBUseSlowfall = new System.Windows.Forms.CheckBox();
            this.TBSlowfallSpell = new System.Windows.Forms.TextBox();
            this.RBCloak = new System.Windows.Forms.CheckBox();
            this.TBSlowfallItem = new System.Windows.Forms.TextBox();
            this.GBPull = new System.Windows.Forms.GroupBox();
            this.CBPull2 = new System.Windows.Forms.RadioButton();
            this.CBPull = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.TBRange = new System.Windows.Forms.TextBox();
            this.TBPull = new System.Windows.Forms.TextBox();
            this.CBBlazewing = new System.Windows.Forms.CheckBox();
            this.CBVyragosa = new System.Windows.Forms.CheckBox();
            this.BSave = new System.Windows.Forms.Button();
            this.CBAlert = new System.Windows.Forms.CheckBox();
            this.BAlertTest = new System.Windows.Forms.Button();
            this.CBWisper = new System.Windows.Forms.CheckBox();
            this.CBKeyer = new System.Windows.Forms.CheckBox();
            this.CBGuild = new System.Windows.Forms.CheckBox();
            this.CBNotKillTameable = new System.Windows.Forms.CheckBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.CBInteractNPC = new System.Windows.Forms.CheckBox();
            this.CBAnotherMansTreasure = new System.Windows.Forms.CheckBox();
            this.CBObjects = new System.Windows.Forms.CheckBox();
            this.CBCamel = new System.Windows.Forms.CheckBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.CBTestRaptorNest = new System.Windows.Forms.CheckBox();
            this.CBTestCamel = new System.Windows.Forms.CheckBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.TBTameID = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.CBTameByID = new System.Windows.Forms.CheckBox();
            this.CBTameDefault = new System.Windows.Forms.CheckBox();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.label23 = new System.Windows.Forms.Label();
            this.TBBlacklistTime = new System.Windows.Forms.TextBox();
            this.CBBlacklistCheck = new System.Windows.Forms.CheckBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label4 = new System.Windows.Forms.Label();
            this.CBPlayerScan = new System.Windows.Forms.CheckBox();
            this.CBShadowmeld = new System.Windows.Forms.CheckBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.CBLUAoutput = new System.Windows.Forms.CheckBox();
            this.BSoundfileGuild = new System.Windows.Forms.Button();
            this.BSoundfileWisper = new System.Windows.Forms.Button();
            this.BSoundfileFoundRare = new System.Windows.Forms.Button();
            this.TBSoundfileGuild = new System.Windows.Forms.TextBox();
            this.TBSoundfileWisper = new System.Windows.Forms.TextBox();
            this.TBSoundfileFoundRare = new System.Windows.Forms.TextBox();
            this.CBBNWisper = new System.Windows.Forms.CheckBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.CBAeonaxx = new System.Windows.Forms.CheckBox();
            this.label6 = new System.Windows.Forms.Label();
            this.BDefault = new System.Windows.Forms.Button();
            this.CBDarkSoil = new System.Windows.Forms.CheckBox();
            this.GBAddon.SuspendLayout();
            this.GBSlowfall.SuspendLayout();
            this.GBPull.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.SuspendLayout();
            // 
            // GBAddon
            // 
            this.GBAddon.Controls.Add(this.CBKillList);
            this.GBAddon.Controls.Add(this.label3);
            this.GBAddon.Controls.Add(this.CBLowRAR);
            this.GBAddon.Controls.Add(this.TBHuntByID);
            this.GBAddon.Controls.Add(this.CBBC);
            this.GBAddon.Controls.Add(this.CBHuntByID);
            this.GBAddon.Controls.Add(this.CBWotlk);
            this.GBAddon.Controls.Add(this.CBCata);
            this.GBAddon.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GBAddon.Location = new System.Drawing.Point(7, 9);
            this.GBAddon.Name = "GBAddon";
            this.GBAddon.Size = new System.Drawing.Size(167, 194);
            this.GBAddon.TabIndex = 0;
            this.GBAddon.TabStop = false;
            this.GBAddon.Text = "Raremob Killer";
            // 
            // CBKillList
            // 
            this.CBKillList.AutoSize = true;
            this.CBKillList.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CBKillList.Location = new System.Drawing.Point(6, 113);
            this.CBKillList.Name = "CBKillList";
            this.CBKillList.Size = new System.Drawing.Size(116, 17);
            this.CBKillList.TabIndex = 6;
            this.CBKillList.Text = "Kill Mobs from XML";
            this.CBKillList.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(30, 164);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(42, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "Mob ID";
            // 
            // CBLowRAR
            // 
            this.CBLowRAR.AutoSize = true;
            this.CBLowRAR.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CBLowRAR.Location = new System.Drawing.Point(6, 90);
            this.CBLowRAR.Name = "CBLowRAR";
            this.CBLowRAR.Size = new System.Drawing.Size(128, 17);
            this.CBLowRAR.TabIndex = 3;
            this.CBLowRAR.Text = "All Classic Rare Mobs";
            this.CBLowRAR.UseVisualStyleBackColor = true;
            // 
            // TBHuntByID
            // 
            this.TBHuntByID.Enabled = false;
            this.TBHuntByID.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TBHuntByID.Location = new System.Drawing.Point(78, 159);
            this.TBHuntByID.Name = "TBHuntByID";
            this.TBHuntByID.Size = new System.Drawing.Size(83, 20);
            this.TBHuntByID.TabIndex = 0;
            // 
            // CBBC
            // 
            this.CBBC.AutoSize = true;
            this.CBBC.Checked = true;
            this.CBBC.CheckState = System.Windows.Forms.CheckState.Checked;
            this.CBBC.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CBBC.Location = new System.Drawing.Point(6, 67);
            this.CBBC.Name = "CBBC";
            this.CBBC.Size = new System.Drawing.Size(101, 17);
            this.CBBC.TabIndex = 2;
            this.CBBC.Text = "Bloody Rare BC";
            this.CBBC.UseVisualStyleBackColor = true;
            // 
            // CBHuntByID
            // 
            this.CBHuntByID.AutoSize = true;
            this.CBHuntByID.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CBHuntByID.Location = new System.Drawing.Point(6, 136);
            this.CBHuntByID.Name = "CBHuntByID";
            this.CBHuntByID.Size = new System.Drawing.Size(104, 17);
            this.CBHuntByID.TabIndex = 0;
            this.CBHuntByID.Text = "Hunt Mob by ID:";
            this.CBHuntByID.UseVisualStyleBackColor = true;
            this.CBHuntByID.CheckedChanged += new System.EventHandler(this.CBHuntByID_CheckedChanged);
            // 
            // CBWotlk
            // 
            this.CBWotlk.AutoSize = true;
            this.CBWotlk.Checked = true;
            this.CBWotlk.CheckState = System.Windows.Forms.CheckState.Checked;
            this.CBWotlk.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CBWotlk.Location = new System.Drawing.Point(6, 43);
            this.CBWotlk.Name = "CBWotlk";
            this.CBWotlk.Size = new System.Drawing.Size(117, 17);
            this.CBWotlk.TabIndex = 1;
            this.CBWotlk.Text = "Frostbitten WOTLK";
            this.CBWotlk.UseVisualStyleBackColor = true;
            // 
            // CBCata
            // 
            this.CBCata.AutoSize = true;
            this.CBCata.Checked = true;
            this.CBCata.CheckState = System.Windows.Forms.CheckState.Checked;
            this.CBCata.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CBCata.Location = new System.Drawing.Point(6, 19);
            this.CBCata.Name = "CBCata";
            this.CBCata.Size = new System.Drawing.Size(105, 17);
            this.CBCata.TabIndex = 0;
            this.CBCata.Text = "Cataclysm Rares";
            this.CBCata.UseVisualStyleBackColor = true;
            // 
            // CBPoseidus
            // 
            this.CBPoseidus.AutoSize = true;
            this.CBPoseidus.Checked = true;
            this.CBPoseidus.CheckState = System.Windows.Forms.CheckState.Checked;
            this.CBPoseidus.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CBPoseidus.Location = new System.Drawing.Point(6, 42);
            this.CBPoseidus.Name = "CBPoseidus";
            this.CBPoseidus.Size = new System.Drawing.Size(69, 17);
            this.CBPoseidus.TabIndex = 5;
            this.CBPoseidus.Text = "Poseidus";
            this.CBPoseidus.UseVisualStyleBackColor = true;
            // 
            // CBTLPD
            // 
            this.CBTLPD.AutoSize = true;
            this.CBTLPD.Checked = true;
            this.CBTLPD.CheckState = System.Windows.Forms.CheckState.Checked;
            this.CBTLPD.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CBTLPD.Location = new System.Drawing.Point(6, 19);
            this.CBTLPD.Name = "CBTLPD";
            this.CBTLPD.Size = new System.Drawing.Size(120, 17);
            this.CBTLPD.TabIndex = 4;
            this.CBTLPD.Text = "Timelost Protodrake";
            this.CBTLPD.UseVisualStyleBackColor = true;
            // 
            // CBMOP
            // 
            this.CBMOP.AutoSize = true;
            this.CBMOP.Enabled = false;
            this.CBMOP.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CBMOP.Location = new System.Drawing.Point(15, 113);
            this.CBMOP.Name = "CBMOP";
            this.CBMOP.Size = new System.Drawing.Size(105, 17);
            this.CBMOP.TabIndex = 3;
            this.CBMOP.Text = "MOP Rare Mobs";
            this.CBMOP.UseVisualStyleBackColor = true;
            // 
            // CBRaptorNest
            // 
            this.CBRaptorNest.AutoSize = true;
            this.CBRaptorNest.Checked = true;
            this.CBRaptorNest.CheckState = System.Windows.Forms.CheckState.Checked;
            this.CBRaptorNest.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CBRaptorNest.Location = new System.Drawing.Point(6, 42);
            this.CBRaptorNest.Name = "CBRaptorNest";
            this.CBRaptorNest.Size = new System.Drawing.Size(123, 17);
            this.CBRaptorNest.TabIndex = 5;
            this.CBRaptorNest.Text = "Collect Raptor Nests";
            this.CBRaptorNest.UseVisualStyleBackColor = true;
            // 
            // GBSlowfall
            // 
            this.GBSlowfall.Controls.Add(this.TBFalltimer);
            this.GBSlowfall.Controls.Add(this.label10);
            this.GBSlowfall.Controls.Add(this.CBSpell);
            this.GBSlowfall.Controls.Add(this.CBItem);
            this.GBSlowfall.Controls.Add(this.CBUseSlowfall);
            this.GBSlowfall.Controls.Add(this.TBSlowfallSpell);
            this.GBSlowfall.Controls.Add(this.RBCloak);
            this.GBSlowfall.Controls.Add(this.TBSlowfallItem);
            this.GBSlowfall.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GBSlowfall.Location = new System.Drawing.Point(6, 6);
            this.GBSlowfall.Name = "GBSlowfall";
            this.GBSlowfall.Size = new System.Drawing.Size(173, 195);
            this.GBSlowfall.TabIndex = 2;
            this.GBSlowfall.TabStop = false;
            this.GBSlowfall.Text = "Slowfall Behavior";
            // 
            // TBFalltimer
            // 
            this.TBFalltimer.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TBFalltimer.Location = new System.Drawing.Point(71, 167);
            this.TBFalltimer.Name = "TBFalltimer";
            this.TBFalltimer.Size = new System.Drawing.Size(80, 20);
            this.TBFalltimer.TabIndex = 5;
            this.TBFalltimer.Text = "700";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(21, 170);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(48, 13);
            this.label10.TabIndex = 4;
            this.label10.Text = "Falltimer:";
            // 
            // CBSpell
            // 
            this.CBSpell.AutoSize = true;
            this.CBSpell.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CBSpell.Location = new System.Drawing.Point(24, 42);
            this.CBSpell.Name = "CBSpell";
            this.CBSpell.Size = new System.Drawing.Size(110, 17);
            this.CBSpell.TabIndex = 3;
            this.CBSpell.Text = "Use Slowfall Spell";
            this.CBSpell.UseVisualStyleBackColor = true;
            this.CBSpell.CheckedChanged += new System.EventHandler(this.CBSpell_CheckedChanged);
            // 
            // CBItem
            // 
            this.CBItem.AutoSize = true;
            this.CBItem.Checked = true;
            this.CBItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.CBItem.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CBItem.Location = new System.Drawing.Point(23, 116);
            this.CBItem.Name = "CBItem";
            this.CBItem.Size = new System.Drawing.Size(107, 17);
            this.CBItem.TabIndex = 2;
            this.CBItem.Text = "Use Slowfall Item";
            this.CBItem.UseVisualStyleBackColor = true;
            this.CBItem.CheckedChanged += new System.EventHandler(this.RBItem_CheckedChanged);
            // 
            // CBUseSlowfall
            // 
            this.CBUseSlowfall.AutoSize = true;
            this.CBUseSlowfall.Checked = true;
            this.CBUseSlowfall.CheckState = System.Windows.Forms.CheckState.Checked;
            this.CBUseSlowfall.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CBUseSlowfall.Location = new System.Drawing.Point(6, 19);
            this.CBUseSlowfall.Name = "CBUseSlowfall";
            this.CBUseSlowfall.Size = new System.Drawing.Size(84, 17);
            this.CBUseSlowfall.TabIndex = 0;
            this.CBUseSlowfall.Text = "Use Slowfall";
            this.CBUseSlowfall.UseVisualStyleBackColor = true;
            this.CBUseSlowfall.CheckedChanged += new System.EventHandler(this.CBUseSlowfall_CheckedChanged);
            // 
            // TBSlowfallSpell
            // 
            this.TBSlowfallSpell.Enabled = false;
            this.TBSlowfallSpell.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TBSlowfallSpell.Location = new System.Drawing.Point(23, 65);
            this.TBSlowfallSpell.Name = "TBSlowfallSpell";
            this.TBSlowfallSpell.Size = new System.Drawing.Size(128, 20);
            this.TBSlowfallSpell.TabIndex = 0;
            // 
            // RBCloak
            // 
            this.RBCloak.AutoSize = true;
            this.RBCloak.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RBCloak.Location = new System.Drawing.Point(24, 92);
            this.RBCloak.Name = "RBCloak";
            this.RBCloak.Size = new System.Drawing.Size(127, 17);
            this.RBCloak.TabIndex = 1;
            this.RBCloak.Text = "Use Parachute Cloak";
            this.RBCloak.UseVisualStyleBackColor = true;
            // 
            // TBSlowfallItem
            // 
            this.TBSlowfallItem.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TBSlowfallItem.Location = new System.Drawing.Point(23, 139);
            this.TBSlowfallItem.Name = "TBSlowfallItem";
            this.TBSlowfallItem.Size = new System.Drawing.Size(128, 20);
            this.TBSlowfallItem.TabIndex = 0;
            this.TBSlowfallItem.Text = "Snowfall Lager";
            // 
            // GBPull
            // 
            this.GBPull.Controls.Add(this.CBPull2);
            this.GBPull.Controls.Add(this.CBPull);
            this.GBPull.Controls.Add(this.label1);
            this.GBPull.Controls.Add(this.TBRange);
            this.GBPull.Controls.Add(this.TBPull);
            this.GBPull.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GBPull.Location = new System.Drawing.Point(185, 6);
            this.GBPull.Name = "GBPull";
            this.GBPull.Size = new System.Drawing.Size(168, 127);
            this.GBPull.TabIndex = 3;
            this.GBPull.TabStop = false;
            this.GBPull.Text = "customize Pullspell";
            // 
            // CBPull2
            // 
            this.CBPull2.AutoSize = true;
            this.CBPull2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CBPull2.Location = new System.Drawing.Point(8, 43);
            this.CBPull2.Name = "CBPull2";
            this.CBPull2.Size = new System.Drawing.Size(128, 17);
            this.CBPull2.TabIndex = 4;
            this.CBPull2.Text = "Customized Pull Spell:";
            this.CBPull2.UseVisualStyleBackColor = true;
            this.CBPull2.CheckedChanged += new System.EventHandler(this.CBPull2_CheckedChanged_1);
            // 
            // CBPull
            // 
            this.CBPull.AutoSize = true;
            this.CBPull.Checked = true;
            this.CBPull.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CBPull.Location = new System.Drawing.Point(8, 20);
            this.CBPull.Name = "CBPull";
            this.CBPull.Size = new System.Drawing.Size(105, 17);
            this.CBPull.TabIndex = 4;
            this.CBPull.TabStop = true;
            this.CBPull.Text = "Default Pull Spell";
            this.CBPull.UseVisualStyleBackColor = true;
            this.CBPull.CheckedChanged += new System.EventHandler(this.CBPull_CheckedChanged_1);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(6, 97);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Pull-Range";
            // 
            // TBRange
            // 
            this.TBRange.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TBRange.Location = new System.Drawing.Point(71, 94);
            this.TBRange.Name = "TBRange";
            this.TBRange.Size = new System.Drawing.Size(63, 20);
            this.TBRange.TabIndex = 1;
            this.TBRange.Text = "10";
            // 
            // TBPull
            // 
            this.TBPull.Enabled = false;
            this.TBPull.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TBPull.Location = new System.Drawing.Point(34, 61);
            this.TBPull.Name = "TBPull";
            this.TBPull.Size = new System.Drawing.Size(128, 20);
            this.TBPull.TabIndex = 0;
            // 
            // CBBlazewing
            // 
            this.CBBlazewing.AutoSize = true;
            this.CBBlazewing.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CBBlazewing.Location = new System.Drawing.Point(5, 81);
            this.CBBlazewing.Name = "CBBlazewing";
            this.CBBlazewing.Size = new System.Drawing.Size(89, 17);
            this.CBBlazewing.TabIndex = 10;
            this.CBBlazewing.Text = "kill Blazewing";
            this.CBBlazewing.UseVisualStyleBackColor = true;
            // 
            // CBVyragosa
            // 
            this.CBVyragosa.AutoSize = true;
            this.CBVyragosa.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CBVyragosa.Location = new System.Drawing.Point(5, 104);
            this.CBVyragosa.Name = "CBVyragosa";
            this.CBVyragosa.Size = new System.Drawing.Size(85, 17);
            this.CBVyragosa.TabIndex = 8;
            this.CBVyragosa.Text = "kill Vyragosa";
            this.CBVyragosa.UseVisualStyleBackColor = true;
            // 
            // BSave
            // 
            this.BSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BSave.Location = new System.Drawing.Point(279, 499);
            this.BSave.Name = "BSave";
            this.BSave.Size = new System.Drawing.Size(103, 35);
            this.BSave.TabIndex = 5;
            this.BSave.Text = "Save";
            this.BSave.UseVisualStyleBackColor = true;
            this.BSave.Click += new System.EventHandler(this.BSave_Click);
            // 
            // CBAlert
            // 
            this.CBAlert.AutoSize = true;
            this.CBAlert.Checked = true;
            this.CBAlert.CheckState = System.Windows.Forms.CheckState.Checked;
            this.CBAlert.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CBAlert.Location = new System.Drawing.Point(6, 19);
            this.CBAlert.Name = "CBAlert";
            this.CBAlert.Size = new System.Drawing.Size(80, 17);
            this.CBAlert.TabIndex = 6;
            this.CBAlert.Text = "Found Mob";
            this.CBAlert.UseVisualStyleBackColor = true;
            // 
            // BAlertTest
            // 
            this.BAlertTest.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BAlertTest.Location = new System.Drawing.Point(271, 404);
            this.BAlertTest.Name = "BAlertTest";
            this.BAlertTest.Size = new System.Drawing.Size(85, 28);
            this.BAlertTest.TabIndex = 7;
            this.BAlertTest.Text = "Sound Test";
            this.BAlertTest.UseVisualStyleBackColor = true;
            this.BAlertTest.Click += new System.EventHandler(this.BAlertTest_Click);
            // 
            // CBWisper
            // 
            this.CBWisper.AutoSize = true;
            this.CBWisper.Checked = true;
            this.CBWisper.CheckState = System.Windows.Forms.CheckState.Checked;
            this.CBWisper.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CBWisper.Location = new System.Drawing.Point(6, 84);
            this.CBWisper.Name = "CBWisper";
            this.CBWisper.Size = new System.Drawing.Size(59, 17);
            this.CBWisper.TabIndex = 11;
            this.CBWisper.Text = "Wisper";
            this.CBWisper.UseVisualStyleBackColor = true;
            // 
            // CBKeyer
            // 
            this.CBKeyer.AutoSize = true;
            this.CBKeyer.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CBKeyer.Location = new System.Drawing.Point(185, 139);
            this.CBKeyer.Name = "CBKeyer";
            this.CBKeyer.Size = new System.Drawing.Size(82, 17);
            this.CBKeyer.TabIndex = 12;
            this.CBKeyer.Text = "ANTI-AFK";
            this.CBKeyer.UseVisualStyleBackColor = true;
            // 
            // CBGuild
            // 
            this.CBGuild.AutoSize = true;
            this.CBGuild.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CBGuild.Location = new System.Drawing.Point(6, 140);
            this.CBGuild.Name = "CBGuild";
            this.CBGuild.Size = new System.Drawing.Size(50, 17);
            this.CBGuild.TabIndex = 16;
            this.CBGuild.Text = "Guild";
            this.CBGuild.UseVisualStyleBackColor = true;
            // 
            // CBNotKillTameable
            // 
            this.CBNotKillTameable.AutoSize = true;
            this.CBNotKillTameable.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CBNotKillTameable.Location = new System.Drawing.Point(7, 43);
            this.CBNotKillTameable.Name = "CBNotKillTameable";
            this.CBNotKillTameable.Size = new System.Drawing.Size(139, 17);
            this.CBNotKillTameable.TabIndex = 12;
            this.CBNotKillTameable.Text = "don\'t kill tameable Mobs";
            this.CBNotKillTameable.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.CBDarkSoil);
            this.groupBox3.Controls.Add(this.CBInteractNPC);
            this.groupBox3.Controls.Add(this.CBAnotherMansTreasure);
            this.groupBox3.Controls.Add(this.CBRaptorNest);
            this.groupBox3.Controls.Add(this.CBObjects);
            this.groupBox3.Controls.Add(this.CBCamel);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(180, 9);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(167, 165);
            this.groupBox3.TabIndex = 3;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Collector";
            // 
            // CBInteractNPC
            // 
            this.CBInteractNPC.AutoSize = true;
            this.CBInteractNPC.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CBInteractNPC.Location = new System.Drawing.Point(6, 136);
            this.CBInteractNPC.Name = "CBInteractNPC";
            this.CBInteractNPC.Size = new System.Drawing.Size(140, 17);
            this.CBInteractNPC.TabIndex = 7;
            this.CBInteractNPC.Text = "Interact NPCs from XML";
            this.CBInteractNPC.UseVisualStyleBackColor = true;
            // 
            // CBAnotherMansTreasure
            // 
            this.CBAnotherMansTreasure.AutoSize = true;
            this.CBAnotherMansTreasure.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CBAnotherMansTreasure.Location = new System.Drawing.Point(6, 67);
            this.CBAnotherMansTreasure.Name = "CBAnotherMansTreasure";
            this.CBAnotherMansTreasure.Size = new System.Drawing.Size(131, 17);
            this.CBAnotherMansTreasure.TabIndex = 6;
            this.CBAnotherMansTreasure.Text = "AnotherMansTreasure";
            this.CBAnotherMansTreasure.UseVisualStyleBackColor = true;
            // 
            // CBObjects
            // 
            this.CBObjects.AutoSize = true;
            this.CBObjects.Checked = true;
            this.CBObjects.CheckState = System.Windows.Forms.CheckState.Checked;
            this.CBObjects.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CBObjects.Location = new System.Drawing.Point(6, 113);
            this.CBObjects.Name = "CBObjects";
            this.CBObjects.Size = new System.Drawing.Size(145, 17);
            this.CBObjects.TabIndex = 3;
            this.CBObjects.Text = "Collect Objects from XML";
            this.CBObjects.UseVisualStyleBackColor = true;
            // 
            // CBCamel
            // 
            this.CBCamel.AutoSize = true;
            this.CBCamel.Checked = true;
            this.CBCamel.CheckState = System.Windows.Forms.CheckState.Checked;
            this.CBCamel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CBCamel.Location = new System.Drawing.Point(6, 19);
            this.CBCamel.Name = "CBCamel";
            this.CBCamel.Size = new System.Drawing.Size(135, 17);
            this.CBCamel.TabIndex = 3;
            this.CBCamel.Text = "Collect Camel Figurines";
            this.CBCamel.UseVisualStyleBackColor = true;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.CBTestRaptorNest);
            this.groupBox6.Controls.Add(this.CBTestCamel);
            this.groupBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox6.Location = new System.Drawing.Point(9, 35);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(174, 72);
            this.groupBox6.TabIndex = 6;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Developer Box";
            // 
            // CBTestRaptorNest
            // 
            this.CBTestRaptorNest.AutoSize = true;
            this.CBTestRaptorNest.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CBTestRaptorNest.Location = new System.Drawing.Point(6, 19);
            this.CBTestRaptorNest.Name = "CBTestRaptorNest";
            this.CBTestRaptorNest.Size = new System.Drawing.Size(130, 17);
            this.CBTestRaptorNest.TabIndex = 9;
            this.CBTestRaptorNest.Text = "Testcase Raptor Nest";
            this.CBTestRaptorNest.UseVisualStyleBackColor = true;
            // 
            // CBTestCamel
            // 
            this.CBTestCamel.AutoSize = true;
            this.CBTestCamel.Enabled = false;
            this.CBTestCamel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CBTestCamel.Location = new System.Drawing.Point(6, 42);
            this.CBTestCamel.Name = "CBTestCamel";
            this.CBTestCamel.Size = new System.Drawing.Size(149, 17);
            this.CBTestCamel.TabIndex = 6;
            this.CBTestCamel.Text = "Testcase Figurine Interact";
            this.CBTestCamel.UseVisualStyleBackColor = true;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(370, 481);
            this.tabControl1.TabIndex = 14;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Controls.Add(this.groupBox11);
            this.tabPage1.Controls.Add(this.groupBox5);
            this.tabPage1.Controls.Add(this.groupBox3);
            this.tabPage1.Controls.Add(this.groupBox12);
            this.tabPage1.Controls.Add(this.GBAddon);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(362, 455);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Rarekiller";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.CBTLPD);
            this.groupBox1.Controls.Add(this.CBPoseidus);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(7, 210);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(167, 94);
            this.groupBox1.TabIndex = 18;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Mounts";
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.label2);
            this.groupBox11.Controls.Add(this.CBBlazewing);
            this.groupBox11.Controls.Add(this.CBVyragosa);
            this.groupBox11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox11.Location = new System.Drawing.Point(7, 310);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(167, 135);
            this.groupBox11.TabIndex = 16;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Mobs with Problems";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(6, 17);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(161, 52);
            this.label2.TabIndex = 13;
            this.label2.Text = "Sometimes the Bot has problems\r\nto kill these Mobs.\r\nActivate the Buttons at your" +
                " own\r\nrisk (see Forum for further infos)";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.TBTameID);
            this.groupBox5.Controls.Add(this.label11);
            this.groupBox5.Controls.Add(this.CBTameByID);
            this.groupBox5.Controls.Add(this.CBNotKillTameable);
            this.groupBox5.Controls.Add(this.CBTameDefault);
            this.groupBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox5.Location = new System.Drawing.Point(180, 180);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(167, 124);
            this.groupBox5.TabIndex = 13;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "TheTamer";
            // 
            // TBTameID
            // 
            this.TBTameID.Enabled = false;
            this.TBTameID.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TBTameID.Location = new System.Drawing.Point(69, 89);
            this.TBTameID.Name = "TBTameID";
            this.TBTameID.Size = new System.Drawing.Size(83, 20);
            this.TBTameID.TabIndex = 15;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(21, 92);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(42, 13);
            this.label11.TabIndex = 1;
            this.label11.Text = "Mob ID";
            // 
            // CBTameByID
            // 
            this.CBTameByID.AutoSize = true;
            this.CBTameByID.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CBTameByID.Location = new System.Drawing.Point(7, 66);
            this.CBTameByID.Name = "CBTameByID";
            this.CBTameByID.Size = new System.Drawing.Size(81, 17);
            this.CBTameByID.TabIndex = 14;
            this.CBTameByID.Text = "Tame by ID";
            this.CBTameByID.UseVisualStyleBackColor = true;
            this.CBTameByID.CheckedChanged += new System.EventHandler(this.CBTameID_CheckedChanged);
            // 
            // CBTameDefault
            // 
            this.CBTameDefault.AutoSize = true;
            this.CBTameDefault.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CBTameDefault.Location = new System.Drawing.Point(7, 19);
            this.CBTameDefault.Name = "CBTameDefault";
            this.CBTameDefault.Size = new System.Drawing.Size(125, 17);
            this.CBTameDefault.TabIndex = 13;
            this.CBTameDefault.Text = "Tame Pets from XML";
            this.CBTameDefault.UseVisualStyleBackColor = true;
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.label23);
            this.groupBox12.Controls.Add(this.TBBlacklistTime);
            this.groupBox12.Controls.Add(this.CBBlacklistCheck);
            this.groupBox12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox12.Location = new System.Drawing.Point(180, 310);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(167, 79);
            this.groupBox12.TabIndex = 17;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "Blacklist Mobs";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(83, 46);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(49, 13);
            this.label23.TabIndex = 2;
            this.label23.Text = "Seconds";
            // 
            // TBBlacklistTime
            // 
            this.TBBlacklistTime.Location = new System.Drawing.Point(22, 43);
            this.TBBlacklistTime.Name = "TBBlacklistTime";
            this.TBBlacklistTime.Size = new System.Drawing.Size(55, 20);
            this.TBBlacklistTime.TabIndex = 1;
            // 
            // CBBlacklistCheck
            // 
            this.CBBlacklistCheck.AutoSize = true;
            this.CBBlacklistCheck.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CBBlacklistCheck.Location = new System.Drawing.Point(7, 20);
            this.CBBlacklistCheck.Name = "CBBlacklistCheck";
            this.CBBlacklistCheck.Size = new System.Drawing.Size(89, 17);
            this.CBBlacklistCheck.TabIndex = 0;
            this.CBBlacklistCheck.Text = "Blacklist after";
            this.CBBlacklistCheck.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.CBPlayerScan);
            this.tabPage2.Controls.Add(this.CBShadowmeld);
            this.tabPage2.Controls.Add(this.CBKeyer);
            this.tabPage2.Controls.Add(this.BAlertTest);
            this.tabPage2.Controls.Add(this.GBPull);
            this.tabPage2.Controls.Add(this.groupBox8);
            this.tabPage2.Controls.Add(this.GBSlowfall);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(362, 455);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Slowfall and other Behavior";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(216, 206);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(99, 13);
            this.label4.TabIndex = 17;
            this.label4.Text = "with Players around";
            // 
            // CBPlayerScan
            // 
            this.CBPlayerScan.AutoSize = true;
            this.CBPlayerScan.Location = new System.Drawing.Point(185, 186);
            this.CBPlayerScan.Name = "CBPlayerScan";
            this.CBPlayerScan.Size = new System.Drawing.Size(142, 17);
            this.CBPlayerScan.TabIndex = 16;
            this.CBPlayerScan.Text = "Collector: Avoid Objects ";
            this.CBPlayerScan.UseVisualStyleBackColor = true;
            // 
            // CBShadowmeld
            // 
            this.CBShadowmeld.AutoSize = true;
            this.CBShadowmeld.Location = new System.Drawing.Point(186, 163);
            this.CBShadowmeld.Name = "CBShadowmeld";
            this.CBShadowmeld.Size = new System.Drawing.Size(87, 17);
            this.CBShadowmeld.TabIndex = 15;
            this.CBShadowmeld.Text = "Shadowmeld";
            this.CBShadowmeld.UseVisualStyleBackColor = true;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.CBLUAoutput);
            this.groupBox8.Controls.Add(this.BSoundfileGuild);
            this.groupBox8.Controls.Add(this.BSoundfileWisper);
            this.groupBox8.Controls.Add(this.BSoundfileFoundRare);
            this.groupBox8.Controls.Add(this.TBSoundfileGuild);
            this.groupBox8.Controls.Add(this.TBSoundfileWisper);
            this.groupBox8.Controls.Add(this.TBSoundfileFoundRare);
            this.groupBox8.Controls.Add(this.CBBNWisper);
            this.groupBox8.Controls.Add(this.CBWisper);
            this.groupBox8.Controls.Add(this.CBGuild);
            this.groupBox8.Controls.Add(this.CBAlert);
            this.groupBox8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox8.Location = new System.Drawing.Point(9, 230);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(347, 168);
            this.groupBox8.TabIndex = 14;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Alerts";
            // 
            // CBLUAoutput
            // 
            this.CBLUAoutput.AutoSize = true;
            this.CBLUAoutput.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CBLUAoutput.Location = new System.Drawing.Point(6, 42);
            this.CBLUAoutput.Name = "CBLUAoutput";
            this.CBLUAoutput.Size = new System.Drawing.Size(163, 17);
            this.CBLUAoutput.TabIndex = 16;
            this.CBLUAoutput.Text = "LUA Output (WOW Window)";
            this.CBLUAoutput.UseVisualStyleBackColor = true;
            // 
            // BSoundfileGuild
            // 
            this.BSoundfileGuild.Location = new System.Drawing.Point(309, 136);
            this.BSoundfileGuild.Name = "BSoundfileGuild";
            this.BSoundfileGuild.Size = new System.Drawing.Size(28, 23);
            this.BSoundfileGuild.TabIndex = 18;
            this.BSoundfileGuild.Text = "...";
            this.BSoundfileGuild.UseVisualStyleBackColor = true;
            this.BSoundfileGuild.Click += new System.EventHandler(this.BSoundfileGuild_Click);
            // 
            // BSoundfileWisper
            // 
            this.BSoundfileWisper.Location = new System.Drawing.Point(309, 92);
            this.BSoundfileWisper.Name = "BSoundfileWisper";
            this.BSoundfileWisper.Size = new System.Drawing.Size(28, 23);
            this.BSoundfileWisper.TabIndex = 18;
            this.BSoundfileWisper.Text = "...";
            this.BSoundfileWisper.UseVisualStyleBackColor = true;
            this.BSoundfileWisper.Click += new System.EventHandler(this.BSoundfileWisper_Click);
            // 
            // BSoundfileFoundRare
            // 
            this.BSoundfileFoundRare.Location = new System.Drawing.Point(309, 15);
            this.BSoundfileFoundRare.Name = "BSoundfileFoundRare";
            this.BSoundfileFoundRare.Size = new System.Drawing.Size(28, 23);
            this.BSoundfileFoundRare.TabIndex = 18;
            this.BSoundfileFoundRare.Text = "...";
            this.BSoundfileFoundRare.UseVisualStyleBackColor = true;
            this.BSoundfileFoundRare.Click += new System.EventHandler(this.BSoundfileFoundRare_Click);
            // 
            // TBSoundfileGuild
            // 
            this.TBSoundfileGuild.Location = new System.Drawing.Point(89, 138);
            this.TBSoundfileGuild.Name = "TBSoundfileGuild";
            this.TBSoundfileGuild.Size = new System.Drawing.Size(214, 20);
            this.TBSoundfileGuild.TabIndex = 17;
            // 
            // TBSoundfileWisper
            // 
            this.TBSoundfileWisper.Location = new System.Drawing.Point(89, 94);
            this.TBSoundfileWisper.Name = "TBSoundfileWisper";
            this.TBSoundfileWisper.Size = new System.Drawing.Size(214, 20);
            this.TBSoundfileWisper.TabIndex = 17;
            // 
            // TBSoundfileFoundRare
            // 
            this.TBSoundfileFoundRare.Location = new System.Drawing.Point(89, 17);
            this.TBSoundfileFoundRare.Name = "TBSoundfileFoundRare";
            this.TBSoundfileFoundRare.Size = new System.Drawing.Size(214, 20);
            this.TBSoundfileFoundRare.TabIndex = 17;
            // 
            // CBBNWisper
            // 
            this.CBBNWisper.AutoSize = true;
            this.CBBNWisper.Checked = true;
            this.CBBNWisper.CheckState = System.Windows.Forms.CheckState.Checked;
            this.CBBNWisper.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CBBNWisper.Location = new System.Drawing.Point(6, 107);
            this.CBBNWisper.Name = "CBBNWisper";
            this.CBBNWisper.Size = new System.Drawing.Size(74, 17);
            this.CBBNWisper.TabIndex = 11;
            this.CBBNWisper.Text = "BNWisper";
            this.CBBNWisper.UseVisualStyleBackColor = true;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.CBAeonaxx);
            this.tabPage3.Controls.Add(this.CBMOP);
            this.tabPage3.Controls.Add(this.label6);
            this.tabPage3.Controls.Add(this.groupBox6);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(362, 455);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Dev Box";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // CBAeonaxx
            // 
            this.CBAeonaxx.AutoSize = true;
            this.CBAeonaxx.Enabled = false;
            this.CBAeonaxx.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CBAeonaxx.Location = new System.Drawing.Point(15, 136);
            this.CBAeonaxx.Name = "CBAeonaxx";
            this.CBAeonaxx.Size = new System.Drawing.Size(67, 17);
            this.CBAeonaxx.TabIndex = 6;
            this.CBAeonaxx.Text = "Aeonaxx";
            this.CBAeonaxx.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(6, 13);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(156, 13);
            this.label6.TabIndex = 7;
            this.label6.Text = "Just to Test my Functions:";
            // 
            // BDefault
            // 
            this.BDefault.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BDefault.Location = new System.Drawing.Point(12, 499);
            this.BDefault.Name = "BDefault";
            this.BDefault.Size = new System.Drawing.Size(106, 35);
            this.BDefault.TabIndex = 15;
            this.BDefault.Text = "Default Values";
            this.BDefault.UseVisualStyleBackColor = true;
            this.BDefault.Click += new System.EventHandler(this.button1_Click);
            // 
            // CBDarkSoil
            // 
            this.CBDarkSoil.AutoSize = true;
            this.CBDarkSoil.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CBDarkSoil.Location = new System.Drawing.Point(6, 90);
            this.CBDarkSoil.Name = "CBDarkSoil";
            this.CBDarkSoil.Size = new System.Drawing.Size(104, 17);
            this.CBDarkSoil.TabIndex = 16;
            this.CBDarkSoil.Text = "Collect Dark Soil";
            this.CBDarkSoil.UseVisualStyleBackColor = true;
            // 
            // RarekillerUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(394, 546);
            this.Controls.Add(this.BDefault);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.BSave);
            this.Name = "RarekillerUI";
            this.Text = "Rarekiller - Config";
            this.GBAddon.ResumeLayout(false);
            this.GBAddon.PerformLayout();
            this.GBSlowfall.ResumeLayout(false);
            this.GBSlowfall.PerformLayout();
            this.GBPull.ResumeLayout(false);
            this.GBPull.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox GBAddon;
        private System.Windows.Forms.CheckBox CBTLPD;
        private System.Windows.Forms.CheckBox CBLowRAR;
        private System.Windows.Forms.CheckBox CBBC;
        private System.Windows.Forms.CheckBox CBWotlk;
        private System.Windows.Forms.CheckBox CBCata;
        private System.Windows.Forms.GroupBox GBSlowfall;
        private System.Windows.Forms.GroupBox GBPull;
        private System.Windows.Forms.TextBox TBHuntByID;
        private System.Windows.Forms.CheckBox CBHuntByID;
        private System.Windows.Forms.TextBox TBSlowfallSpell;
        private System.Windows.Forms.TextBox TBSlowfallItem;
        private System.Windows.Forms.CheckBox CBUseSlowfall;
        private System.Windows.Forms.TextBox TBPull;
        private System.Windows.Forms.Button BSave;
        private System.Windows.Forms.CheckBox CBAlert;
        private System.Windows.Forms.Button BAlertTest;
        private System.Windows.Forms.CheckBox CBVyragosa;
        private System.Windows.Forms.CheckBox CBSpell;
        private System.Windows.Forms.CheckBox CBItem;
        private System.Windows.Forms.CheckBox RBCloak;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox CBWisper;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.CheckBox CBCamel;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TextBox TBFalltimer;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.CheckBox CBNotKillTameable;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TextBox TBTameID;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.CheckBox CBTameByID;
        private System.Windows.Forms.CheckBox CBTameDefault;
        private System.Windows.Forms.CheckBox CBRaptorNest;
        private System.Windows.Forms.CheckBox CBKeyer;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.CheckBox CBTestCamel;
        private System.Windows.Forms.CheckBox CBTestRaptorNest;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.CheckBox CBGuild;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button BSoundfileGuild;
        private System.Windows.Forms.Button BSoundfileWisper;
        private System.Windows.Forms.Button BSoundfileFoundRare;
        private System.Windows.Forms.TextBox TBSoundfileGuild;
        private System.Windows.Forms.TextBox TBSoundfileWisper;
        private System.Windows.Forms.TextBox TBSoundfileFoundRare;
        private System.Windows.Forms.CheckBox CBBlazewing;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox TBBlacklistTime;
        private System.Windows.Forms.CheckBox CBBlacklistCheck;
        private System.Windows.Forms.CheckBox CBPoseidus;
        private System.Windows.Forms.Button BDefault;
        private System.Windows.Forms.CheckBox CBObjects;
        private System.Windows.Forms.RadioButton CBPull2;
        private System.Windows.Forms.RadioButton CBPull;
        private System.Windows.Forms.CheckBox CBMOP;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TBRange;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox CBBNWisper;
        private System.Windows.Forms.CheckBox CBInteractNPC;
        private System.Windows.Forms.CheckBox CBAnotherMansTreasure;
        private System.Windows.Forms.CheckBox CBShadowmeld;
        private System.Windows.Forms.CheckBox CBKillList;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox CBAeonaxx;
        private System.Windows.Forms.CheckBox CBLUAoutput;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox CBPlayerScan;
        private System.Windows.Forms.CheckBox CBDarkSoil;
    }
}

