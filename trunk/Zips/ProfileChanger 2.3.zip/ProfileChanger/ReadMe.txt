Hello ppl

This Plugin will change your Profile every x Minutes.
You could insert up to 6 different Profiles and 6 different Times.

You could choose between Stop Bot after 6th Profile and circle the Profiles again.

How to use:
1. Make sure you have the latest version of Honorbuddy
2. Extract the ZIP in your HonorBuddy/Plugins folder and enable it
3. Activate the Lines with the Checkboxes
4. Choose your Files and insert the Minutes how long the File should run.
5. Press Save
6. Choose your Botbase (maybe GB2) with a valid File and start the Bot. (this file wouldn't be used it is just to start hb)

Attentione:
It in your own responibility to verify:
- your choosen Profiles are on the same Continent
- your choosen Profiles are working for the choosen Botbase and with your Char
Changing the Botbase isn't impemented yet. If you are interested in this, post here. 
If some more people want/need it I may implement it, too.

Version 1.0: 
Release Version - 12.04.2011

Version 1.1:
Save Settings in a configfile
SVN Autoupdater installed

Version 1.2
Use Heartstone between Profiles possible

Version 2.0
Expandet to 12 Lines
Implemented Use Portal after Profile