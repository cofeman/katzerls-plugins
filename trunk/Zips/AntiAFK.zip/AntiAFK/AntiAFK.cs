using System;
using System.Collections.Generic;
using System.Threading;
using System.Linq;
using System.Xml.Linq;
using System.Diagnostics;
using System.IO;
using System.Xml;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Media;
using System.Windows.Media;
using System.Net;
using System.Globalization;



using Styx;
using Styx.Common;
using Styx.CommonBot;
using Styx.Helpers;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using Styx.Plugins;
using Styx.Pathing;

namespace katzerle
{
	class AntiAFK: HBPlugin
	{	
		public static string name { get { return "AntiAFK"; } }
		public override string Name { get { return name; } }
		public override string Author { get { return "katzerle"; } }
		private readonly static Version _version = new Version(1, 0);
		public override Version Version { get { return _version; } }
		public override string ButtonText { get { return "No Settings"; } }
		public override bool WantButton { get { return false; } }
		
		public static LocalPlayer Me = StyxWoW.Me;
		private static Stopwatch Checktimer = new Stopwatch();
		public static Random rnd = new Random();
        public static bool hasItBeenInitialized = false;
        Int32 MoveTimer = 50;
		
		public static bool LeftRight = true;
		public static bool WisperAlert = true;
		
		public override void OnButtonPress()
		{
		}
		
		public AntiAFK()
        {
			Logging.Write(Colors.MediumPurple, "Anti AFK loaded");
        }

        static private void BotStopped(EventArgs args)
        {
			Chat.Whisper -= newWhisper;
            Lua.Events.DetachEvent("CHAT_MSG_BN_WHISPER", BNWhisper);
			BotEvents.OnBotStopped -= BotStopped;
            hasItBeenInitialized = false;
        }
		
		public override void Initialize()
        {
// Register the events of the Stop Button in HB
			BotEvents.OnBotStopped += BotStopped;
//Alerts Wisper and Guild
			Chat.Whisper += newWhisper;
            Lua.Events.AttachEvent("CHAT_MSG_BN_WHISPER", BNWhisper);
		}
		
		public override void Pulse()
		{
			try
			{
// ------------ Deactivate if not in Game etc
                if (Me == null || !StyxWoW.IsInGame || inCombat || Me.IsCasting)
                    return;
				
// ------------ Part Init
                if (!hasItBeenInitialized)
                {
                    Initialize();
					hasItBeenInitialized = true;
					Logging.WriteDiagnostic(Colors.MediumPurple, "Anti AFK - Init done");
					
                }
				
				if(!Checktimer.IsRunning)
					Checktimer.Start();
				
				if (!Checktimer.IsRunning || Checktimer.Elapsed.TotalSeconds > MoveTimer)
				{
					MoveTimer = rnd.Next(36, 54);
					Logging.Write(Colors.MediumPurple, "Anti AFK - Next Timer {0} Seconds", MoveTimer);
					Movearound();
					Checktimer.Reset();
					Checktimer.Start();
				}				
			}
			catch (ThreadAbortException) { }
			catch (Exception e)
			{
				Logging.Write(Colors.Red, "AntiAFK Exception: {0}", e.Message);
			}
		}
		
		//Keypresser
		static public void Movearound()
        {
            
            if (LeftRight)
            {
                WoWMovement.Move(WoWMovement.MovementDirection.TurnLeft);
				Logging.WriteDiagnostic(Colors.MediumPurple, "AntiAFK move around, Left");
				Thread.Sleep(10);
				WoWMovement.MoveStop();
                LeftRight = false;
            }
            else
            {
				WoWMovement.Move(WoWMovement.MovementDirection.TurnRight);
				Logging.WriteDiagnostic(Colors.MediumPurple, "AntiAFK move around, Right");
                Thread.Sleep(10);
				WoWMovement.MoveStop();
                LeftRight = true;
            }
        }
		
		

		static public string FolderPath
        {
            get
            {
                string sPath = Process.GetCurrentProcess().MainModule.FileName;
                sPath = Path.GetDirectoryName(sPath);
                sPath = Path.Combine(sPath, "Plugins\\AntiAFK\\");
                return sPath;
            }
        }
		
//Wisperalert
		static public string SoundfileWisper
        {
            get
            {
				string sPath = Path.Combine(FolderPath, "attention.wav");
                return sPath;
            }
        }
		
		static public void newWhisper(Chat.ChatWhisperEventArgs arg)
        {
			if(WisperAlert)
			{
				if (File.Exists(SoundfileWisper))
					new SoundPlayer(SoundfileWisper).Play();
				else
					Logging.Write(Colors.Red, "Alert playing SoundfileWisper failes");
			}
			Logging.Write(Colors.Pink, "You got a Wisper: {0}: {1} - Timestamp: {2}: {3}", arg.Author, arg.Message,  DateTime.Now.ToShortDateString(), DateTime.Now.ToShortTimeString());
        }
        static public void BNWhisper(object sender, LuaEventArgs args)
        {
            object[] Args = args.Args;
            string Message = Args[0].ToString();
            string presenceId = Args[12].ToString();
            string Author = Lua.GetReturnValues(String.Format("return BNGetFriendInfoByID({0})", presenceId))[3];

			if(WisperAlert)
			{
				if (File.Exists(SoundfileWisper))
					new SoundPlayer(SoundfileWisper).Play();
				else
					Logging.WriteDiagnostic(Colors.Red, "Alert playing SoundfileWisper failes");
			}
            Logging.Write(Colors.Aqua, "You got a BN Wisper: {0}: {1} - Timestamp: {2}: {3}", Author, Message,  DateTime.Now.ToShortDateString(), DateTime.Now.ToShortTimeString());
        }

				
//Function In Combat
        static public bool inCombat
        {
            get
            {
                if (Me == null || !StyxWoW.IsInGame || Me.Combat || Me.IsDead || Me.IsGhost || InPetCombat()) return true;
                return false;
            }
        }

        static public bool InPetCombat()
        {
            List<string> cnt = Lua.GetReturnValues("dummy,reason=C_PetBattles.IsTrapAvailable() return dummy,reason");

            if (cnt != null) { if (cnt[1] != "0") return true; }
            return false;
        }
	}
}

